#
# Program version number is declared here.
#

__version__ = '0.2.6'
